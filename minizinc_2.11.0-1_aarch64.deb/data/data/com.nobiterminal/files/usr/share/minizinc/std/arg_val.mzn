include "fzn_arg_val_bool.mzn";
include "fzn_arg_val_bool_opt.mzn";
include "fzn_arg_val_float.mzn";
include "fzn_arg_val_float_opt.mzn";
include "fzn_arg_val_int.mzn";
include "fzn_arg_val_int_opt.mzn";

predicate fzn_arg_val_bool(array [int] of var bool: xs, var bool: value, var int: idx);
predicate fzn_arg_val_bool_opt(array [int] of var opt bool: xs, var opt bool: value, var int: idx);
predicate fzn_arg_val_float(array [int] of var float: xs, var float: value, var int: idx);
predicate fzn_arg_val_float_opt(array [int] of var opt float: xs, var opt float: value, var int: idx);
predicate fzn_arg_val_int(array [int] of var int: xs, var int: value, var int: idx);
predicate fzn_arg_val_int_opt(array [int] of var opt int: xs, var opt int: value, var int: idx);

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function $$E: arg_val(array [$$E] of $T: xs, $T: value) =
  let { any: matches = [i | i in index_set(xs) where xs[i] = value] } in matches[1];

/** @group globals.math
	Returns the index of the value \a value in the array \a xs when \a value.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function opt $$E: arg_val_weak(array [$$E] of $T: xs, $T: value) =
  let {
    any: matches = [i | i in index_set(xs) where xs[i] = value];
  } in if length(matches) = 0 then <> else matches[1] endif;

% Builtin versions of arg_val and arg_val_weak for par arrays of strings and integers. They
% build a hash map from values to indices on first use and reuse it for later calls on the same
% array, so repeated lookups in one array take constant time.

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function $$E: arg_val(array [$$E] of string: xs, string: value);

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function opt $$E: arg_val_weak(array [$$E] of string: xs, string: value);

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function $$E: arg_val(array [$$E] of $$F: xs, $$F: value);

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function opt $$E: arg_val_weak(array [$$E] of $$F: xs, $$F: value);

/** @group globals.math
	Returns a value that occurs more than once in the array \a xs, or absent
	if all values in \a xs are distinct. If several values occur more than once,
	the one whose second occurrence has the least index is returned.
*/
function opt string: first_duplicate(array [$$E] of string: xs);

/** @group globals.math
	Returns a value that occurs more than once in the array \a xs, or absent
	if all values in \a xs are distinct. If several values occur more than once,
	the one whose second occurrence has the least index is returned.
*/
function opt $$F: first_duplicate(array [$$E] of $$F: xs);

% The number of value-to-index maps built so far by arg_val, arg_val_weak and
% first_duplicate. Only for testing that the maps are reused.
function int: mzn_arg_val_index_builds();

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function var $$E: arg_val(array [$$E] of var bool: xs, var bool: value) =
  let {
    constraint length(xs) > 0;
  } in to_enum_internal(enum_of(index_set(xs)), arg_val_total(index2int(xs), value));

function var int: arg_val_total(array [int] of var bool: xs, var bool: value) :: promise_total =
  if length(xs) = 0 then
    min(index_set(xs))
  else
    let {
      var index_set(xs): i;
      constraint fzn_arg_val_bool(xs, value, i);
    } in i
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs when \a value.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function var opt $$E: arg_val_weak(array [$$E] of var bool: xs, var bool: value) =
  to_enum_internal(enum_of(index_set(xs)), arg_val_weak_bool(index2int(xs), value));
function var opt int: arg_val_weak_bool(array [int] of var bool: xs, var bool: value) :: promise_total =
  if length(xs) = 0 then
    <>
  else
    let {
      set of int: idx = min(index_set(xs))..max(index_set(xs)) + 1;
      any: xx = array1d(idx, xs ++ [value]);
      var idx: i;
      var opt index_set(xs): ii = if i in index_set(xs) then i else <> endif;
      constraint fzn_arg_val_bool(xx, value, i);
    } in ii
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function var $$E: arg_val(array [$$E] of var opt bool: xs, var opt bool: value) =
  let {
    constraint length(xs) > 0;
  } in to_enum_internal(enum_of(index_set(xs)), arg_val_total(index2int(xs), value));

function var int: arg_val_total(array [int] of var opt bool: xs, var opt bool: value) :: promise_total =
  if length(xs) = 0 then
    min(index_set(xs))
  else
    let {
      var index_set(xs): i;
      constraint fzn_arg_val_bool_opt(xs, value, i);
    } in i
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs when \a value.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function var opt $$E: arg_val_weak(array [$$E] of var opt bool: xs, var opt bool: value) =
  to_enum_internal(enum_of(index_set(xs)), arg_val_weak_opt_bool(index2int(xs), value));
function var opt int: arg_val_weak_opt_bool(array [int] of var opt bool: xs, var opt bool: value)
  :: promise_total =
  if length(xs) = 0 then
    <>
  else
    let {
      set of int: idx = min(index_set(xs))..max(index_set(xs)) + 1;
      any: xx = array1d(idx, xs ++ [value]);
      var idx: i;
      var opt index_set(xs): ii = if i in index_set(xs) then i else <> endif;
      constraint fzn_arg_val_bool_opt(xx, value, i);
    } in ii
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function var $$E: arg_val(array [$$E] of var float: xs, var float: value) =
  let {
    constraint length(xs) > 0;
  } in to_enum_internal(enum_of(index_set(xs)), arg_val_total(index2int(xs), value));

function var int: arg_val_total(array [int] of var float: xs, var float: value) :: promise_total =
  if length(xs) = 0 then
    min(index_set(xs))
  else
    let {
      var index_set(xs): i;
      constraint fzn_arg_val_float(xs, value, i);
    } in i
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs when \a value.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function var opt $$E: arg_val_weak(array [$$E] of var float: xs, var float: value) =
  to_enum_internal(enum_of(index_set(xs)), arg_val_weak_float(index2int(xs), value));
function var opt int: arg_val_weak_float(array [int] of var float: xs, var float: value)
   :: promise_total =
  if length(xs) = 0 then
    <>
  else
    let {
      set of int: idx = min(index_set(xs))..max(index_set(xs)) + 1;
      any: xx = array1d(idx, xs ++ [value]);
      var idx: i;
      var opt index_set(xs): ii = if i in index_set(xs) then i else <> endif;
      constraint fzn_arg_val_float(xx, value, i);
    } in ii
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function var $$E: arg_val(array [$$E] of var opt float: xs, var float: value) =
  let {
    constraint length(xs) > 0;
  } in to_enum_internal(enum_of(index_set(xs)), arg_val_total(index2int(xs), value));

function var int: arg_val_total(array [int] of var opt float: xs, var opt float: value)
  :: promise_total =
  if length(xs) = 0 then
    min(index_set(xs))
  else
    let {
      var index_set(xs): i;
      constraint fzn_arg_val_float_opt(xs, value, i);
    } in i
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs when \a value.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function var opt $$E: arg_val_weak(array [$$E] of var opt float: xs, var opt float: value) =
  to_enum_internal(enum_of(index_set(xs)), arg_val_weak_opt_float(index2int(xs), value));
function var opt int: arg_val_weak_opt_float(array [int] of var opt float: xs, var opt float: value)
  :: promise_total =
  if length(xs) = 0 then
    <>
  else
    let {
      set of int: idx = min(index_set(xs))..max(index_set(xs)) + 1;
      any: xx = array1d(idx, xs ++ [value]);
      var idx: i;
      var opt index_set(xs): ii = if i in index_set(xs) then i else <> endif;
      constraint fzn_arg_val_float_opt(xx, value, i);
    } in ii
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function var $$E: arg_val(array [$$E] of var $$V: xs, var $$V: value) =
  let {
    constraint length(xs) > 0;
  } in to_enum_internal(enum_of(index_set(xs)), arg_val_total(index2int(enum2int(xs)), enum2int(value)));

function var int: arg_val_total(array [int] of var int: xs, var int: value) :: promise_total =
  if length(xs) = 0 then
    min(index_set(xs))
  else
    let {
      var index_set(xs): i;
      constraint fzn_arg_val_int(xs, value, i);
    } in i
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs when \a value.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function var opt $$E: arg_val_weak(array [$$E] of var $$V: xs, var $$V: value) =
  to_enum_internal(enum_of(index_set(xs)), arg_val_weak_int(index2int(enum2int(xs)), enum2int(value)));
function var opt int: arg_val_weak_int(array [int] of var int: xs, var int: value) :: promise_total =
  if length(xs) = 0 then
    <>
  else
    let {
      set of int: idx = min(index_set(xs))..max(index_set(xs)) + 1;
      any: xx = array1d(idx, xs ++ [value]);
      var idx: i;
      var opt index_set(xs): ii = if i in index_set(xs) then i else <> endif;
      constraint fzn_arg_val_int(xx, value, i);
    } in ii
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs.
	When breaking ties the least index is returned.
	Note that this function forces the value \a value to occur in \a xs.
*/
function var $$E: arg_val(array [$$E] of var opt $$V: xs, var opt $$V: value) =
  let {
    constraint length(xs) > 0;
  } in to_enum_internal(enum_of(index_set(xs)), arg_val_total(index2int(enum2int(xs)), enum2int(value)));

function var int: arg_val_total(array [int] of var opt int: xs, var opt int: value) :: promise_total =
  if length(xs) = 0 then
    min(index_set(xs))
  else
    let {
      var index_set(xs): i;
      constraint fzn_arg_val_int_opt(xs, value, i);
    } in i
  endif;

/** @group globals.math
	Returns the index of the value \a value in the array \a xs when \a value.
	When breaking ties the least index is returned.
	Returns absent when \a value does not occur in \a xs.
*/
function var opt $$E: arg_val_weak(array [$$E] of var opt $$V: xs, var opt $$V: value) =
  to_enum_internal(
    enum_of(index_set(xs)),
    arg_val_weak_opt_int(index2int(enum2int(xs)), enum2int(value)),
  );
function var opt int: arg_val_weak_opt_int(array [int] of var opt int: xs, var opt int: value)
  :: promise_total =
  if length(xs) = 0 then
    <>
  else
    let {
      set of int: idx = min(index_set(xs))..max(index_set(xs)) + 1;
      any: xx = array1d(idx, xs ++ [value]);
      var idx: i;
      var opt index_set(xs): ii = if i in index_set(xs) then i else <> endif;
      constraint fzn_arg_val_int_opt(xx, value, i);
    } in ii
  endif;
