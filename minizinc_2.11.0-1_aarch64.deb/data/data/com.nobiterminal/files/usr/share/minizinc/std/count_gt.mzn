include "fzn_count_gt.mzn";
include "fzn_count_gt_reif.mzn";
include "fzn_count_gt_bool.mzn";
include "fzn_count_gt_bool_reif.mzn";
include "fzn_count_gt_float.mzn";
include "fzn_count_gt_float_reif.mzn";
include "fzn_count_gt_set.mzn";
include "fzn_count_gt_set_reif.mzn";
include "fzn_count_gt_par.mzn";
include "fzn_count_gt_par_reif.mzn";
include "fzn_count_gt_bool_par.mzn";
include "fzn_count_gt_bool_par_reif.mzn";
include "fzn_count_gt_float_par.mzn";
include "fzn_count_gt_float_par_reif.mzn";
include "fzn_count_gt_set_par.mzn";
include "fzn_count_gt_set_par_reif.mzn";

predicate fzn_count_gt(array [int] of var int: xs, var int: value, var int: n);
predicate fzn_count_gt_bool(array [int] of var bool: xs, var bool: value, var int: n);
predicate fzn_count_gt_bool_par(array [int] of var bool: xs, bool: value, int: n);
predicate fzn_count_gt_float(array [int] of var float: xs, var float: value, var int: n);
predicate fzn_count_gt_float_par(array [int] of var float: xs, float: value, int: n);
predicate fzn_count_gt_par(array [int] of var int: xs, int: value, int: n);
predicate fzn_count_gt_set(array [int] of var set of int: xs, var set of int: value, var int: n);
predicate fzn_count_gt_set_par(array [int] of var set of int: xs, set of int: value, int: n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs. 
*/
predicate count_gt(array [$X] of var $$E: xs, var $$E: value, var int: n) =
  fzn_count_gt(enum2int(array1d(xs)), enum2int(value), n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs.
*/
predicate count_gt(array [$X] of var bool: xs, var bool: value, var int: n) =
  fzn_count_gt_bool(array1d(xs), value, n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs.
*/
predicate count_gt(array [$X] of var float: xs, var float: value, var int: n) =
  fzn_count_gt_float(array1d(xs), value, n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs.
*/
predicate count_gt(array [$X] of var set of $$E: xs, var set of $$E: value, var int: n) =
  fzn_count_gt_set(enum2int(array1d(xs)), enum2int(value), n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs. 
*/
predicate count_gt(array [$X] of var opt $$E: xs, var $$E: value, var int: n) =
  let {
    % Set <> to something not value
    int: def = if 0 in enum2int(dom(value)) then enum2int(lb(value)) - 1 else 0 endif;
  } in count_gt([i default to_enum_internal(enum_of(value), def) | i in xs], value, n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs. 
*/
predicate count_gt(array [$X] of var $$E: xs, $$E: value, int: n) =
  fzn_count_gt_par(enum2int(array1d(xs)), enum2int(value), n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs.
*/
predicate count_gt(array [$X] of var bool: xs, bool: value, int: n) =
  fzn_count_gt_bool_par(array1d(xs), value, n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs.
*/
predicate count_gt(array [$X] of var float: xs, float: value, int: n) =
  fzn_count_gt_float_par(array1d(xs), value, n);

/** @group globals.counting
  Constrains \a n to be strictly greater than the number of occurrences
  of \a value in \a xs.
*/
predicate count_gt(array [$X] of var set of $$E: xs, set of $$E: value, int: n) =
  fzn_count_gt_set_par(enum2int(array1d(xs)), enum2int(value), n);

%-----------------------------------------------------------------------------%
