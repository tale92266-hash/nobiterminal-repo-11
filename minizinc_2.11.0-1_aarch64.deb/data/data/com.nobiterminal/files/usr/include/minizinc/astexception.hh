/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */

/*
 *  Main authors:
 *     Guido Tack <guido.tack@monash.edu>
 */

/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#pragma once

#include <minizinc/ast.hh>
#include <minizinc/exception.hh>
#include <minizinc/memory.hh>
#include <minizinc/model.hh>
#include <minizinc/stackdump.hh>

#include <memory>
#include <string>

namespace MiniZinc {

class CyclicIncludeError : public Exception {
protected:
  std::shared_ptr<const std::vector<ASTString>> _cycle;

public:
  CyclicIncludeError(std::vector<ASTString> cycle)
      : Exception(""), _cycle(std::make_shared<const std::vector<ASTString>>(std::move(cycle))) {}
  const char* what() const noexcept override { return "cyclic include error"; }

  void print(std::ostream& os) const override;
  void json(std::ostream& os) const override;
};

class LocationException : public Exception {
protected:
  std::shared_ptr<StackDump> _stack;
  Location _loc;
  bool _dumpStack = false;

public:
  LocationException(Location loc, const std::string& msg);
  LocationException(EnvI& env, Location loc, const std::string& msg);
  const Location& loc() const { return _loc; }

  bool dumpStack() const { return _dumpStack; }
  void dumpStack(bool dump) { _dumpStack = dump; }

  void print(std::ostream& os) const override;
  void json(std::ostream& os) const override;
};

class SyntaxError : public LocationException {
protected:
  std::shared_ptr<const std::string> _currentLine;
  std::shared_ptr<const std::vector<ASTString>> _includeStack;

public:
  SyntaxError(const Location& loc, const std::string& msg)
      : LocationException(loc, msg),
        _currentLine(std::make_shared<const std::string>()),
        _includeStack(std::make_shared<const std::vector<ASTString>>()) {}
  SyntaxError(const Location& loc, std::string currentLine, std::vector<ASTString> includeStack,
              const std::string& msg)
      : LocationException(loc, msg),
        _currentLine(std::make_shared<const std::string>(std::move(currentLine))),
        _includeStack(std::make_shared<const std::vector<ASTString>>(std::move(includeStack))) {}
  const char* what() const noexcept override { return "syntax error"; }

  void print(std::ostream& os) const override;
  void json(std::ostream& os) const override;
};

class IncludeError : public LocationException {
public:
  IncludeError(EnvI& env, const Location& loc, const std::string& msg)
      : LocationException(env, loc, msg) {}
  const char* what() const noexcept override { return "include error"; }
};

class TypeError : public LocationException {
public:
  TypeError(EnvI& env, const Location& loc, const std::string& msg)
      : LocationException(env, loc, msg) {}
  const char* what() const noexcept override { return "type error"; }
};

class EvalError : public LocationException {
public:
  EvalError(EnvI& env, const Location& loc, const std::string& msg)
      : LocationException(env, loc, msg) {}
  EvalError(EnvI& env, const Location& loc, const std::string& msg, const ASTString& name)
      : LocationException(env, loc, "") {
    std::ostringstream ss;
    ss << msg << " '" << name << "'";
    setMsg(ss.str());
  }
  const char* what() const noexcept override { return "evaluation error"; }
};

class AssertionError : public EvalError {
public:
  AssertionError(EnvI& env, const Location& loc, const std::string& msg)
      : EvalError(env, loc, msg) {}
  const char* what() const noexcept override { return "assertion failed"; }
};

class ModelInconsistent : public LocationException {
public:
  ModelInconsistent(EnvI& env, const Location& loc, const std::string& msg = "")
      : LocationException(env, loc,
                          "model inconsistency detected" + (msg.empty() ? msg : ":  ") + msg) {}
  const char* what() const noexcept override { return "warning"; }
};

class ResultUndefinedError : public LocationException {
private:
  int _warningIdx;

public:
  ResultUndefinedError(EnvI& env, const Location& loc, const std::string& msg);
  const char* what() const noexcept override { return "result of evaluation is undefined"; }
  int warningIdx() const { return _warningIdx; }
};

}  // namespace MiniZinc
