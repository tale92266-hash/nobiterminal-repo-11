{application, 'rabbitmq_federation', [
	{description, "Deprecated no-op RabbitMQ Federation"},
	{vsn, "4.4.1"},
	{id, "aa914c5"},
	{modules, ['rabbitmq_federation_noop']},
	{registered, []},
	{applications, [kernel,stdlib,rabbit,rabbitmq_queue_federation,rabbitmq_exchange_federation]},
	{optional_applications, []},
	{env, []}
]}.