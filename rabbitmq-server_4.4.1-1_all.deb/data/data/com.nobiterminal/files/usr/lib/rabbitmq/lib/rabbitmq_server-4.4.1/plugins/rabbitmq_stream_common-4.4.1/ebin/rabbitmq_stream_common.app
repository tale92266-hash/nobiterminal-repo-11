{application, 'rabbitmq_stream_common', [
	{description, "RabbitMQ Stream Common"},
	{vsn, "4.4.1"},
	{id, "aa914c5"},
	{modules, ['rabbit_stream_core']},
	{registered, []},
	{applications, [kernel,stdlib,osiris]},
	{optional_applications, []},
	{env, [
]}
]}.