{application, 'rabbitmq_event_exchange', [
	{description, "Event Exchange Type"},
	{vsn, "4.4.1"},
	{id, "aa914c5"},
	{modules, ['rabbit_event_exchange_decorator','rabbit_exchange_type_event']},
	{registered, []},
	{applications, [kernel,stdlib,rabbit_common,rabbit]},
	{optional_applications, []},
	{env, 	  [
		{protocol, amqp_0_9_1},
		{runtime_parameters_include_value, false}
	  ]},
		{broker_version_requirements, []}
]}.