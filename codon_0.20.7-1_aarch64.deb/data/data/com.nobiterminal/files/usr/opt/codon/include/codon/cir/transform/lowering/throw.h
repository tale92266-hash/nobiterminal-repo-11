// Copyright (C) 2022-2026 Exaloop Inc. <https://exaloop.io>

#pragma once

#include "codon/cir/transform/pass.h"

namespace codon {
namespace ir {
namespace transform {
namespace lowering {

class ThrowLowering : public OperatorPass {
public:
  static CODON_API const std::string KEY;
  std::string getKey() const override { return KEY; }
  void handle(ThrowInstr *value) override;
};

} // namespace lowering
} // namespace transform
} // namespace ir
} // namespace codon
